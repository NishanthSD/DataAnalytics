import matplotlib.pyplot as plt
from sklearn.datasets import load_iris
iris = load_iris()
plt.figure(figsize=(8, 6))
for i, species_name in enumerate(iris.target_names):
    species_data = iris.data[iris.target == i]
    plt.scatter(species_data[:, 2], species_data[:, 3], label=species_name)
plt.xlabel('Petal length (cm)')
plt.ylabel('Petal width (cm)')
plt.title('Iris dataset: petal length vs petal width')
plt.legend()
plt.show()
