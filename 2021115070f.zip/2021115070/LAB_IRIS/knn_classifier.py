def dis(p1,p2):
    sq = 0
    for i,j in zip(p1,p2):
        sq += (i - j) ** 2
    return sq ** 0.5
def knn(points,labels,test_point,k):
    '''Brute Force not efficient'''
    dists = []
    kk = 0
    for i in points:
        for j in i:
            dists.append([dis(j,test_point),labels[kk]])
        kk += 1
    dists.sort()
    freq = [0 for i in range(len(labels))]
    dic = {labels[i]:i for i in range(len(labels))}
    for i in range(k):
        freq[dic[dists[i][1]]] += 1
    mx,ps = -10**9,0
    for i in range(len(labels)):
        if freq[i] > mx:
            mx = freq[i]
            ps = i
    return labels[ps]

if __name__ == "__main__":
    points = []
    dum = []
    for i in range(6):
        for j in range(6):
            dum.append([i,j])
    points.append(dum)
    points
    dum = []
    for i in range(6,11):
        for j in range(6,11):
            dum.append([i,j])

    points.append(dum)

    labels = ['A','B']

    print(knn(points,labels,[10,3],5))
