import socket as s
import threading as th
from math import *

def rcv(sck):
    while True:
        st = sck.recv(1024).decode()
        print(st)
        sck.send(("Evaluated Result : " + str(eval(st)) + "\n").encode())
sck = s.socket(s.AF_INET,s.SOCK_STREAM)
sck.bind(("127.0.0.1",3015))
sck.listen(2)
print("Waiting for clients....")
sk,addr = sck.accept()
print("CONNECTED : ",addr)
t1 = th.Thread(target=rcv,args=(sk,))
t1.start()
t1.join()


