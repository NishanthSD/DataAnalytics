import socket as s
import threading as th

lis = []
lock = th.Lock()  # Thread lock for synchronization

def listen_thread(sck):
    while True:
        c, addr = sck.accept()
        with lock:
            lis.append(c)
        t = th.Thread(target=rcv, args=(c,))
        t.start()
        print("CREATED")

def rcv(c):
    while True:
        lt = c.recv(1024).decode()
        with lock:
            for i in lis:
                if i != c:  # Don't send the message back to the sender
                    i.send(lt.encode())
        if not lt:
            break  # Client disconnected

sck = s.socket(s.AF_INET, s.SOCK_STREAM)
sck.bind(("127.0.0.1", 4501))
sck.listen(10)

listen_thread(sck)

# Keep the main thread alive
try:
    while True:
        pass
except KeyboardInterrupt:
    print("Server shutting down...")
    sck.close()  # Close the server socket
