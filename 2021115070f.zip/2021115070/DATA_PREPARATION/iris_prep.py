import pandas as pd

iris = pd.read_csv("iris.csv")
print(len(iris.to_numpy()))
iris.dropna(inplace=True)
print(len(iris.to_numpy()))